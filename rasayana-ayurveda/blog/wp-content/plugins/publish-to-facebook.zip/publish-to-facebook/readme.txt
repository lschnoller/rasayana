This plugin gives Wordpress the ability to publish to your Facebook Mini-Feed.

Installation:
1) Upload the publishtofacebook.php to your Wordpress plugins directory.
2) Activate the plugin from your admin interface.
3) Go to Options->Publish to Facebook in your admin interface and select whether you want to use this functionality for posts, pages or both.

Once the option is set every time you publish a post, page or both you will be brought to the Facebook login page and, after logging in, the article will be added to the Mini-Feed section of your profile.
